<div class="left-sidebar bg-black-300 bg-black-blue box-shadow ">
                        <div class="sidebar-content">
                            <br>
                            <div class="user-info">
                                <img src="http://placehold.it/90/c2c2c2?text=<?php echo htmlentities($uname) ?>" alt="userimg" class="img-circle profile-img">
                                <h6 class="title">Roll No : <?php echo htmlentities($uname); ?></h6>
                            </div>
                            <!-- /.user-info -->
                            <hr style="width:50px;">
                            <div class="sidebar-nav">
                                <ul class="side-nav color-gray">
                                    <li class="nav-header">
                                        <span class="">Main Category</span>
                                    </li>
                                    <li>
                                        <a href="Sdashboard.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span> </a>
                                    </li>
									<li class="nav-header">
                                        <span class="">Activities</span>
                                    </li>
                                    <li>
                                        <a href="supdate-details.php"><i class="fa fa-bars"></i><span>Update Details</span></a>
                                    </li>
                                    <li>
                                        <a href="schange-password.php"><i class="fa fa fa-server"></i><span>Change Password</span></a>
                                    </li>
                                   
                                </ul>
                            </div>
                            <!-- /.sidebar-nav -->
                        </div>
                        <!-- /.sidebar-content -->
                    </div>