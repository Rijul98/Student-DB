require("amcharts3/amcharts/amcharts.js");
require("./responsive.min.js");
